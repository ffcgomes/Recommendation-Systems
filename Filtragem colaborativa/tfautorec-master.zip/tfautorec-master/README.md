# tfautorec
Collaborative Filtering Autoencoder Neural Network
